'use strict';
require('./ENC/index.js');
