const fs = require("fs")

//===========================//

const {
smsg, getGroupAdmins, formatp, tanggal, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, jsonformat, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize
} = require("./trashbase/lib/myfunction")

//===========================//

global.d = new Date()
global.calender = d.toLocaleDateString("id")

//===========================//

global.prefa = ['','!','.',',','🧙‍♂️','🗿']
global.owner = ["6283166640349"]
global.ownMain = "6287739444295"
global.NamaOwner = "decode.id"
global.usePairingCode = true // Ubah Ke False Jika Ingin Menggunakan Qr Code
global.filenames = "Manta.js"
global.namabot = "Manta X "
global.author = "Xrelly9CoreXx ϟ"
global.packname = "Manta - TrashDex "
global.yt = "https://youtube.com/@RellyMods"
global.hiasan = `	◦  `
global.gris = '`'

//===========================//

//===========================//

global.xchannel = {
	jid: '120363298524333143@newsletter'
	}

//===========================//

global.country = `62`
global.system = {
gmail: `Manta@gmail.com`,
}

//===========================//

global.nick = {
aaa: "⭑̤⟅̊༑ ▾ 𝐙͢𝐍ͮ𝐗 ⿻ 𝐈𝐍͢𝐕𝚫𝐒𝐈͢𝚯𝚴 ⿻ ▾ ༑̴⟆̊‏‎‏‎‏‎‏⭑̤‏‎‏‎‏‎‏",
sss: "Manta - TrashDex "
}

global.mess = {
 ingroup: '*𝐎𝐧𝐥𝐲 𝐆𝐫𝐨𝐮𝐩 𝐁𝐫𝐨 😹*',
 admin: '*𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐚𝐝𝐦𝐢𝐧 😹*',
 owner: '*𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐨𝐰𝐧𝐞𝐫 😹*',
 premium: '*𝐘𝐨𝐮 𝐚𝐫𝐞 𝐧𝐨𝐭 𝐏𝐫𝐞𝐦𝐢𝐮𝐦 𝐔𝐬𝐞𝐫 😹*',
 wait: '*𝙒𝙖𝙞𝙩𝙞𝙣𝙜 𝙁𝙤𝙧 𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜🔥*',
 success: '*𝐃𝐨𝐧𝐞 𝐁𝐲 𝐌𝐚𝐧𝐭𝐚 𝐗*',
 bugrespon: '*𝐖𝐚𝐢𝐭 𝐚 𝐦𝐢𝐧𝐮𝐭𝐞*'
}

//===========================//

global.autOwn = 'req(62-8S57547ms11).287p'
let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})