'use strict';
const crypto=require("crypto");
const fs=require("fs");
const path=require("path");
process.chdir(path.join(__dirname,".."));
const M={"files":[{"file":"main.js","hash":"6b0571c08aab9b85552849976b419526a3d98e7260ba9fe83ef1293806a9c546"},{"file":"Manta.js","hash":"600c1de2ba66f7453bcc1475635087133adcf5fd6c700769ef19c6c8bd31328b"}]};
function v(file,hash){
  const p=path.join(__dirname,file);
  if(!fs.existsSync(p)){console.error("[ENC] Missing",file);process.exit(1);}
  const h=crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");
  if(h!==hash){console.error("[ENC] Tamper detected:",file);process.exit(1);}
}
for(const x of M.files)v(x.file,x.hash);
require("./main.js");
