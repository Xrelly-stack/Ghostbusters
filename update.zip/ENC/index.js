'use strict';
const crypto=require("crypto");
const fs=require("fs");
const path=require("path");
process.chdir(path.join(__dirname,".."));
const M={"files":[{"file":"main.js","hash":"7eee81df37ec7a793cea8d5b57312439a40d021753dcb150cc8e3092f789a8be"},{"file":"Manta.js","hash":"02f9b8e9942a4bf3b13774f243c87a3a33a09020361e18282e84eed9cc792c77"}]};
function v(file,hash){
  const p=path.join(__dirname,file);
  if(!fs.existsSync(p)){console.error("[ENC] Missing",file);process.exit(1);}
  const h=crypto.createHash("sha256").update(fs.readFileSync(p)).digest("hex");
  if(h!==hash){console.error("[ENC] Tamper detected:",file);process.exit(1);}
}
for(const x of M.files)v(x.file,x.hash);
require("./main.js");
